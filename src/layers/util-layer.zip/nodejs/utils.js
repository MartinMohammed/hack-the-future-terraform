"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SnowflakeRepository = void 0;
const snowflake_sdk_1 = __importDefault(require("snowflake-sdk"));
class SnowflakeRepository {
    constructor(config) {
        this.config = config;
        this.connection = snowflake_sdk_1.default.createConnection({
            account: config.account,
            username: config.username,
            password: config.password,
            database: config.database,
            schema: config.schema,
            warehouse: config.warehouse,
        });
    }
    connect() {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                this.connection.connect((err, conn) => {
                    if (err) {
                        console.error("Error connecting to Snowflake:", err);
                        reject(err);
                        return;
                    }
                    console.log("Successfully connected to Snowflake. Connection ID:", conn.getId());
                    resolve();
                });
            });
        });
    }
    executeQuery(query) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                this.connection.execute({
                    sqlText: query,
                    complete: (err, stmt, rows) => {
                        if (err) {
                            console.error("Error executing query:", err);
                            reject(err);
                            return;
                        }
                        resolve(rows);
                    },
                });
            });
        });
    }
    disconnect() {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                this.connection.destroy((err) => {
                    if (err) {
                        console.error("Error disconnecting from Snowflake:", err);
                        reject(err);
                        return;
                    }
                    console.log("Successfully disconnected from Snowflake");
                    resolve();
                });
            });
        });
    }
}
exports.SnowflakeRepository = SnowflakeRepository;
// Example usage:
/*
const snowflakeConfig: SnowflakeConfig = {
  account: process.env.SNOWFLAKE_ACCOUNT || '',
  username: process.env.SNOWFLAKE_USERNAME || '',
  password: process.env.SNOWFLAKE_PASSWORD || '',
  database: process.env.SNOWFLAKE_DATABASE || '',
  schema: process.env.SNOWFLAKE_SCHEMA || '',
  warehouse: process.env.SNOWFLAKE_WAREHOUSE || ''
};

const snowflakeRepo = new SnowflakeRepository(snowflakeConfig);

try {
  await snowflakeRepo.connect();
  const results = await snowflakeRepo.executeQuery('SELECT * FROM MY_TABLE');
  console.log('Query results:', results);
} catch (error) {
  console.error('Error:', error);
} finally {
  await snowflakeRepo.disconnect();
}
*/
